<?php
require_once 'vendor_fuzzywuzzy/autoload.php';

use FuzzyWuzzy\Fuzz;
use FuzzyWuzzy\Process;

$fuzz = new Fuzz();
$process = new Process($fuzz); // $fuzz is optional here, and can be omitted.

echo $fuzz->partialRatio('this is a test', 'this is a test!');

?>